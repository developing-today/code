# Costs and monthly usage

This chapter is the light cost record for the estate: the shape of the money, the totals the sources carry, and the latest dated usage reads. It keeps two buckets separate from the first section to the last — plan and included usage in one bucket, pay-as-you-go in the other — and it never mixes them. Every figure carries the date its source was read, in the same sentence or the same table row. No figure in this chapter is current. A figure with an old read date is labelled stale with its age. The plan inventory itself, with its fees and windows, is in [The plans we use](the-plans.md); this chapter does not repeat that detail.

## The shape of the money

The estate's spend comes in two shapes, and the fleet's rules treat them as different kinds of money:

- **Plan and included usage.** Fixed-fee plans carry an included allowance metered in windows — a weekly window, a 5-hour window, a monthly bucket. Work burns the allowance, not cash. When a window reaches 100% the pool is closed until its reset; nothing bills past the wall. The monthly usage table below is this bucket.
- **Pay-as-you-go.** Metered spend against a balance, charged per use. The standing rule for supervised sessions is never funds: a quota or funds error is a wall, never a fallback to a balance (POOL MAP, registry, read 2026-11-23). The dated exceptions to that rule, and the one standing reserve, are in the pay-as-you-go section below — kept separate, as the rule requires.

Turso and Cloudflare Workers sit in the first shape: each is a plan with an included allowance, and their sections below record the plan, the estate's measured usage against it, and nothing finer.

## Turso

The estate's databases sit on Turso's Scaler plan (plan named in the #13844 audit record, read 2026-11-23). The #13844 Turso audit measured the estate on 2026-11-23 (live Turso API inventory read 2026-11-23 at 23:05Z, audit merged through PR #13845): 50 databases, ~65.8M rows written, ~7.47B rows read, and ~10.0 GB stored per period (audit, read 2026-11-23). The settled estate list confirms the count: a live `turso db list` on the laptop on 2026-11-23 returned exactly 50 databases (lane TURSO-SETTLE, 2026-11-23). The full estate is enumerated in [Data stores: the Turso estate](../reference/data-stores.md).

Two stores dominate the two meters. On reads, the audit attributes the estate's read volume to `fleet-queue`, the queue broker's core store: 81% of all reads (6.08B rows read), driven by the broker and its pollers (audit, read 2026-11-23; the read-driver attribution is disagreement D40, and the audit's attribution is the one this book follows). On writes, `fleet-platform`, the PM and dashboard plane store, takes 87% of the estate's writes (coverage ledger Table B, census date 2026-11-23).

The D1 migration's cost logic is one paragraph in the audit's programme ([#13844](https://github.com/developing-today/code/issues/13844)): moving the `fleet-platform` families to Cloudflare D1 removes the estate's dominant write load from Turso, and the audit's downgrade path runs from there — a Turso plan downgrade gated on the programme's G1–G3 work plus the G4 read-shape fix (#13844 issue body, read 2026-11-23). At the audit's own record the programme is research and design only; no migrations have been made (issue-map snapshot, 2026-11-23). This chapter records the path and does not re-argue it.

## Cloudflare Workers

The coverage ledger carries 24 worker rows after the D17 correction (coverage ledger, corrected 2026-11-23), and the reconciled arithmetic (D41) is: 24 ledger rows = 21 true Workers + the exec door (a tunnel ingress, not a Worker) + the pm-aggregator (a laptop service, not a Worker) + the dashboard row (a duplicate — the dashboard IS the aggregator UI; its only Worker, `pm-console-edge`, is a separate row). The 21 true Workers are: the security.cab door Workers, 2 (`desktop-commander`, `mcpx`); the PM Workers, 4 (`decision-events`, `voice-line`, `pm-notify`, `pm-console-edge`); the covered three, 3 (`atlas-search`, `id-hosted-worker`, `message-bridge`); the fleet Workers, 2 (`fleet-hosted`, `queue-transport-alert`); the ID Workers, 3 (`mail`, `id-worker-poc`, `id-d1-journal-poc`); the remaining PM-assigned Workers, 5 (`pkarr`, `lab-ops-hub`, `cf-container-hello`, `muse-agent-handoff`, `github-ci`); and the two D17 additions, 2 (`cold-store-rehydrator`, `developing-today-backup`). The per-Worker record is in [The workers](../reference/workers.md).

The quota shape is the Workers Paid plan's included monthly allowance: 10M requests and 30M CPU-ms per month (quota view summary, from records dated 2026-10-20, read 2026-11-23). One dated usage read exists in the sources for this chapter: the laptop collector's first live read, dated 2026-10-29 at 10:04Z, recorded 75,312 requests and 126,527 CPU-ms for the current cycle at that date (quota view, dated update 2026-10-29) — 25 days stale at this chapter's date (2026-11-23), and stated here as a dated read, not a current figure. No fresher Workers usage figure exists in the sources. The live numbers live in the aggregator's `cloudflare-quota-export` (survey `apps.md` §27, census date 2026-11-23), which exports Cloudflare quota and usage into the quota system on its timer; a reader who needs the current cycle reads it there.

## LLM monthly usage across the core quotas

One row per pool. The governing read is the registry cycle 471 gatherer, measured 2026-11-23T12:15Z; at pack assembly (2026-11-24T00:40Z) that read was 12.4 hours old (evidence pack §4, read 2026-11-23). Rows whose own measurement is older carry that date and its age in the row. Wall states in full are in [Walls, resets and quota doctrine](walls-and-resets.md).

| Pool / plan | Included quota shape | Latest dated usage read (date and age) |
|---|---|---|
| OpenAI plan (two doors, one pool) | Weekly window, 168h (plan-facts, read 2026-11-23) | Alt door weekly 100%, resets 2026-11-23T18:49Z; main door weekly 59%, resets 2026-11-24T21:23Z (registry cycle 471, measured 2026-11-23T12:15Z; 12.4 hours old at pack assembly, 2026-11-24T00:40Z) |
| Claude Max | Plan windows 5h and 7d, plus a dedicated Fable 7d window metered separately (plan-facts, read 2026-11-23) | Unmeasured at the governing read: gatherer state error at cycle 471, measured 2026-11-23T12:15Z (the Claude plan's state differs across sources — the gatherer error against the last measurement below — which is disagreement D42). Last actual measurement 2026-11-23T03:00Z carried 5h 100% (past its 04:50Z reset on 2026-11-23) / 7d 32% / Fable 28%, resets 2026-11-25T19:00Z — carried figures, not state (read 2026-11-23) |
| Meta Muse API High Usage (one pool) | Token quota, weekly reset (plan-facts, read 2026-11-23) | Stale: freshest measurement 2026-11-21T04:45Z read weekly 100% resetting 2026-11-23T00:00Z, a reset time past at pack time (2026-11-23); the new window's first clean read had not landed at cycle 471 (read 2026-11-23) |
| OpenCode Go (four workspaces) | One shared bucket per workspace; windows 20%/5h and 50%/week of the bucket (verified 2026-10-27, read 2026-11-23) | drewrypope monthly 100%, resets 2026-12-03; popesdrew monthly 100%, resets 2026-12-03; developing-today-0 monthly 100%, resets 2026-12-08; 0x111dev 5h 64% / weekly 66% / monthly 83%, monthly resets 2026-12-18 (registry cycle 471, measured 2026-11-23T12:15Z; 12.4 hours old at pack assembly) |
| ClinePass | Windows 5h rolling / weekly / monthly (read 2026-11-23) | Monthly 100% closed, resets 2026-12-06T14:40Z; weekly and 5h at 0% (registry cycle 471, measured 2026-11-23T12:15Z; 12.4 hours old at pack assembly) |
| Open Design Go | $10 per 5h and $30 per 7d rolling windows (efficiency plan, dated 2026-10-25) | 7d 100% closed, resets 2026-11-24T11:44Z (registry cycle 471, measured 2026-11-23T12:15Z; 12.4 hours old at pack assembly) |
| Command Code Go | $10 credits/mo included on the Go tier (plan-facts, read 2026-11-23) | Monthly 99.51% (registry cycle 471, measured 2026-11-23T12:15Z; 12.4 hours old at pack assembly) |
| Mistral Education | Two included allowances: API $15/mo and Vibe Code $150/mo, both resetting on the 1st of the calendar month (registry correction, 2026-11-05, read 2026-11-23) | API 100% and Vibe 100%, reset 2026-12-01 — measured 2026-11-16, 7 days stale inside the cycle 471 read itself (read 2026-11-23) |
| Antigravity | Per-family weekly fractions; the Gemini family and the Claude+GPT family wall independently (read 2026-11-23) | Gemini weekly 1.64% and Claude/GPT weekly 1.64%, resets 2026-11-30T01:41Z (registry cycle 471, measured 2026-11-23T12:15Z; 12.4 hours old at pack assembly) |

The free tiers and free catalogues in [The plans we use](the-plans.md) (rows 15–23 and 28, verified 2026-11-23) carry no dated usage percentages in the sources; their shapes are recorded there and no usage figure is stated for them here.

## Pay-as-you-go, separately

Pay-as-you-go is the second bucket, and it stays fenced. The standing rule is never funds (POOL MAP, read 2026-11-23), and the measured reason for the fence is dated: on 2026-10-25 a Meta plan burn spilled $20.00 plus $3.91, $23.91 in total, onto pay-as-you-go charges, with a third $20.00 charge on 2026-10-26 (registry, read 2026-11-23). Against that standing rule, the sources record one standing reserve and three TEMPORARY tails.

The standing reserve is DeepSeek direct (api.deepseek.com, balance-funded). Its role: the pay-as-you-go reserve for when every plan is used up — never a routine route and never an agent default (registry provider facts, read 2026-11-23). Routine DeepSeek comes from plan routes (ClinePass, Open Design, OpenCode Go). Its one dated balance read in the sources is ¥43.82 (registry cycle 404, dated 2026-11-10) — 13 days stale at this chapter's date (2026-11-23), recorded as visibility only.

The three TEMPORARY tails are Drew's dated exception, ordered 2026-11-23 13:20 CST and TEMPORARY until he lifts the order (standing-rules record, read 2026-11-23). Each tail sits last in its pool, behind every plan and free leg, and exists to catch fall-through traffic only after the included allowances are spent:

- **DeepSeek direct pay-as-you-go** — added last in the DeepSeek pool (order, 2026-11-23). This is the standing reserve door above, seated as a tail for the duration of the order.
- **Claude pay-as-you-go Haiku, low** — added last in the Claude pool (order, 2026-11-23).
- **OpenAI pay-as-you-go Luna, low** — added last in the OpenAI pool (order, 2026-11-23).

No other pay-as-you-go balance is stated in this chapter: the sources date-stamp no balance for the Claude or OpenAI tails, and none is given here.

## Plans exist

Some of the arrangements behind the table above are student plans. ChatGPT and Mistral are the named examples (registry rows, read 2026-11-23). This chapter states that those arrangements exist and records nothing further about them — no terms, no conditions, no dates — by the book's standing presentation rule for this chapter. The plan inventory, at the level the book covers it, is in [The plans we use](the-plans.md).

Sources. LLM evidence pack, `~/workspace/pm-book/survey/llm-evidence.md` §1 and §4 (assembled 2026-11-23), and the sources the pack names: REG (provider-quota-registry.md, cycle 471 gatherer measured 2026-11-23T12:15Z, read 2026-11-23), FREE (free-census-2026-11-23.md, dated 2026-11-23); the #13844 Turso audit (live Turso API read 2026-11-23 at 23:05Z, merged through PR #13845) as recorded in `~/workspace/pm-book/coverage-ledger.md` Table B and the gap summary (census date 2026-11-23) and `~/workspace/pm-book/turso-estate-list.md` (settled 2026-11-23); PM-SURVEY survey file `apps.md` §27 (census date 2026-11-23); the stewardship quota view (`quota-view.md`, built 2026-10-25; Cloudflare collector update dated 2026-10-29; its older OpenAI main fee record, $100/mo from records dated 2026-10-20, is superseded by the registry's $200/mo record dated 2026-11-10 and is not used in this chapter).
